<!DOCTYPE html>
<html>
<head>
    <title>Página não encontrada - Sistema de Loteria</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>404 - Página não encontrada</h1>
        <p>A página que você está procurando não existe.</p>
        <p><a href="<?php echo BASE_URL; ?>">Voltar para a página inicial</a></p>
    </div>
</body>
</html> 