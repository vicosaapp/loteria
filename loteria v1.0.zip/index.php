<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';

// Se não estiver logado, redireciona para login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Busca informações do usuário
try {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch();
} catch(PDOException $e) {
    die("Erro ao buscar usuário: " . $e->getMessage());
}

// Define o título da página
$pageTitle = 'Sistema de Loteria';
require_once 'includes/header.php';
?>

<main class="container">
    <div class="card">
        <h2>Bem-vindo, <?php echo htmlspecialchars($usuario['nome']); ?></h2>
        
        <div class="nav-menu">
            <?php if ($usuario['tipo'] === 'admin'): ?>
                <a href="admin/gerenciar_apostas.php" class="btn">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                    </svg>
                    Gerenciar Apostas
                </a>
            <?php else: ?>
                <a href="fazer_aposta.php" class="btn">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Nova Aposta
                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($usuario['tipo'] !== 'admin'): ?>
        <h2>Suas Últimas Apostas</h2>
        <div class="apostas-grid">
            <?php
            try {
                $stmt = $pdo->prepare("SELECT * FROM apostas WHERE usuario_id = ? ORDER BY created_at DESC LIMIT 5");
                $stmt->execute([$usuario['id']]);
                $apostas = $stmt->fetchAll();
                
                if ($apostas): ?>
                    <?php foreach($apostas as $aposta): ?>
                        <div class="aposta-card <?php echo $aposta['status'] === 'aprovada' ? 'aprovada' : ''; ?> fade-in">
                            <div class="aposta-header">
                                <div class="status-tag status-<?php echo $aposta['status']; ?>">
                                    <?php echo ucfirst($aposta['status']); ?>
                                </div>
                            </div>
                            <div class="aposta-body">
                                <p>Data: <?php echo date('d/m/Y H:i', strtotime($aposta['created_at'])); ?></p>
                                <div class="aposta-numeros">
                                    <?php foreach(explode(',', $aposta['numeros']) as $numero): ?>
                                        <div class="numero-bola"><?php echo trim($numero); ?></div>
                                    <?php endforeach; ?>
                                </div>
                                <?php if ($aposta['status'] === 'aprovada' && $aposta['comprovante_path']): ?>
                                    <a href="comprovantes/<?php echo htmlspecialchars($aposta['comprovante_path']); ?>" 
                                       target="_blank" class="btn">Ver Comprovante</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Você ainda não fez nenhuma aposta.</p>
                <?php endif;
                
            } catch(PDOException $e) {
                echo "Erro ao buscar apostas: " . $e->getMessage();
            }
            ?>
        </div>
    <?php endif; ?>
</main>

<?php require_once 'includes/footer.php'; ?> 