<?php
require_once 'includes/header.php';
require_once '../config/database.php';

// Verificar se usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Buscar dados do admin
$stmt = $pdo->prepare("SELECT nome, email FROM usuarios WHERE id = ?");
$stmt->execute([$_SESSION['usuario_id']]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Se não encontrou o usuário, redireciona
if (!$admin) {
    header('Location: login.php');
    exit;
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Configurações</h2>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Dados do Administrador</h6>
        </div>
        <div class="card-body">
            <form id="configForm" method="POST" action="actions/salvar_configuracoes.php">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control" id="nome" name="nome" 
                           value="<?php echo htmlspecialchars($admin['nome'] ?? ''); ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email"
                           value="<?php echo htmlspecialchars($admin['email'] ?? ''); ?>" required>
                </div>

                <div class="form-group">
                    <label for="senha">Nova Senha</label>
                    <input type="password" class="form-control" id="senha" name="senha"
                           placeholder="Deixe em branco para manter a senha atual">
                </div>

                <div class="form-group">
                    <label for="confirmar_senha">Confirmar Nova Senha</label>
                    <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha"
                           placeholder="Confirme a nova senha">
                </div>

                <div class="form-group text-right">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar Alterações
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.card {
    border: none;
    margin-bottom: 1.5rem;
}

.card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}

.text-primary {
    color: #4e73df !important;
}

.form-group {
    margin-bottom: 1rem;
}

.form-control {
    border: 1px solid #d1d3e2;
    border-radius: 0.35rem;
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
}

.form-control:focus {
    border-color: #bac8f3;
    box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
}

.btn-primary {
    background-color: #4e73df;
    border-color: #4e73df;
}

.btn-primary:hover {
    background-color: #2e59d9;
    border-color: #2653d4;
}

.shadow {
    box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.15)!important;
}
</style>

<script>
$(document).ready(function() {
    $('#configForm').on('submit', function(e) {
        e.preventDefault();
        
        if($('#senha').val() !== $('#confirmar_senha').val()) {
            alert('As senhas não coincidem!');
            return;
        }
        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    alert('Dados atualizados com sucesso!');
                } else {
                    alert('Erro ao atualizar: ' + response.message);
                }
            },
            error: function() {
                alert('Erro ao processar a requisição');
            }
        });
    });
});
</script>

<?php 
// Removendo o require do footer pois não existe
// require_once 'includes/footer.php'; 
?> 