<?php
session_start();
require_once '../../config/database.php';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

// Pega os dados do POST
$data = json_decode(file_get_contents('php://input'), true);

try {
    // Validação dos campos obrigatórios
    if (empty($data['nome']) || 
        empty($data['dezenas']) || 
        empty($data['total_numeros']) || 
        empty($data['dezenas_premiar']) || 
        !isset($data['valor']) || 
        !isset($data['premio'])) {
        throw new Exception('Todos os campos são obrigatórios');
    }

    // Prepara os dados
    $id = isset($data['id']) ? $data['id'] : null;
    $nome = trim($data['nome']);
    $total_numeros = intval($data['total_numeros']);
    $dezenas = intval($data['dezenas']);
    $dezenas_premiar = intval($data['dezenas_premiar']);
    $valor = floatval($data['valor']);
    $premio = floatval($data['premio']);
    $status = isset($data['status']) ? intval($data['status']) : 1;

    // Validações adicionais
    if ($total_numeros <= 0) {
        throw new Exception('Total de números deve ser maior que zero');
    }
    if ($dezenas <= 0) {
        throw new Exception('Quantidade de dezenas deve ser maior que zero');
    }
    if ($dezenas > $total_numeros) {
        throw new Exception('Quantidade de dezenas não pode ser maior que o total de números');
    }
    if ($dezenas_premiar <= 0) {
        throw new Exception('Quantidade de acertos deve ser maior que zero');
    }
    if ($dezenas_premiar > $dezenas) {
        throw new Exception('Quantidade de acertos não pode ser maior que dezenas apostadas');
    }
    if ($valor <= 0) {
        throw new Exception('Valor da aposta deve ser maior que zero');
    }
    if ($premio <= 0) {
        throw new Exception('Valor do prêmio deve ser maior que zero');
    }

    // Se tem ID, atualiza. Se não tem, insere
    if ($id) {
        $stmt = $pdo->prepare("
            UPDATE jogos 
            SET nome = ?, 
                total_numeros = ?,
                dezenas = ?, 
                dezenas_premiar = ?,
                valor = ?, 
                premio = ?, 
                status = ?
            WHERE id = ?
        ");
        $stmt->execute([$nome, $total_numeros, $dezenas, $dezenas_premiar, $valor, $premio, $status, $id]);
        $message = 'Jogo atualizado com sucesso!';
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO jogos (nome, total_numeros, dezenas, dezenas_premiar, valor, premio, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$nome, $total_numeros, $dezenas, $dezenas_premiar, $valor, $premio, $status]);
        $message = 'Jogo criado com sucesso!';
    }

    echo json_encode([
        'success' => true,
        'message' => $message
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 