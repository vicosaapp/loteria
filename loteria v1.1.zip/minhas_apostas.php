<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

try {
    $stmt = $pdo->prepare("SELECT * FROM apostas WHERE usuario_id = ? ORDER BY created_at DESC");
    $stmt->execute([$_SESSION['usuario_id']]);
    $apostas = $stmt->fetchAll();
} catch(PDOException $e) {
    die("Erro ao buscar apostas: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Minhas Apostas - Sistema de Loteria</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .aposta-card {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        .aposta-numeros {
            display: flex;
            gap: 10px;
            margin: 10px 0;
        }
        .numero {
            background: #007bff;
            color: white;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        .status-pendente {
            color: #f57c00;
        }
        .status-aprovada {
            color: #2e7d32;
        }
        .status-rejeitada {
            color: #c62828;
        }
        .comprovante {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Minhas Apostas</h2>
        
        <?php if (empty($apostas)): ?>
            <p>Você ainda não fez nenhuma aposta.</p>
        <?php else: ?>
            <?php foreach($apostas as $aposta): ?>
                <div class="aposta-card">
                    <div class="aposta-header">
                        <strong>Data:</strong> <?php echo date('d/m/Y H:i', strtotime($aposta['created_at'])); ?>
                        <span class="status-<?php echo $aposta['status']; ?>">
                            (<?php echo ucfirst($aposta['status']); ?>)
                        </span>
                    </div>
                    
                    <div class="aposta-numeros">
                        <?php 
                        $numeros = explode(',', $aposta['numeros']);
                        foreach($numeros as $numero): 
                        ?>
                            <div class="numero"><?php echo $numero; ?></div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if ($aposta['status'] === 'aprovada' && $aposta['comprovante_path']): ?>
                        <div class="comprovante">
                            <a href="comprovantes/<?php echo htmlspecialchars($aposta['comprovante_path']); ?>" 
                               target="_blank" class="btn-download">
                                Baixar Comprovante
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <p>
            <a href="fazer_aposta.php" class="btn">Fazer Nova Aposta</a>
            <a href="index.php" class="btn">Voltar ao Início</a>
        </p>
    </div>
</body>
</html> 