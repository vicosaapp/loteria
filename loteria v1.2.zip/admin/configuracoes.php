<?php
session_start();
require_once '../config/database.php';

// Define a página atual para o menu
$currentPage = 'configuracoes';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

try {
    // Buscar configurações atuais
    $stmt = $pdo->query("SELECT * FROM configuracoes");
    $configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Buscar dados do admin
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Erro ao buscar informações: " . $e->getMessage());
}

ob_start();
?>

<div class="page-container">
    <div class="page-header">
        <h1><i class="fas fa-cog"></i> Configurações</h1>
        <p>Gerencie as configurações do sistema e sua conta</p>
    </div>

    <div class="content-section">
        <!-- Perfil do Admin -->
        <div class="card mb-4">
            <div class="card-header">
                <h2><i class="fas fa-user-shield"></i> Perfil do Administrador</h2>
            </div>
            <div class="card-body">
                <form id="adminForm" onsubmit="salvarPerfilAdmin(event)">
                    <div class="form-group">
                        <label for="nome">Nome</label>
                        <input type="text" 
                               id="nome" 
                               name="nome" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($admin['nome']); ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($admin['email']); ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label for="senha">Nova Senha (deixe em branco para manter a atual)</label>
                        <input type="password" 
                               id="senha" 
                               name="senha" 
                               class="form-control" 
                               minlength="6">
                    </div>

                    <div class="form-group">
                        <label for="confirmar_senha">Confirmar Nova Senha</label>
                        <input type="password" 
                               id="confirmar_senha" 
                               name="confirmar_senha" 
                               class="form-control" 
                               minlength="6">
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        Atualizar Perfil
                    </button>
                </form>
            </div>
        </div>

     
<style>
.card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.card-header {
    padding: 15px 420px;
    border-bottom: 1px solid #edf2f7;
}

.card-header h2 {
    margin: 0;
    font-size: 1.25rem;
    color: #2d3748;
    display: flex;
    align-items: center;
    gap: 10px;
}

.card-body {
    padding: 20px;
}

.mb-4 {
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: #4e73df;
    font-weight: 500;
}

.form-control {
    width: 100%;
    padding: 10px;
    border: 1px solid #d1d3e2;
    border-radius: 5px;
    font-size: 1rem;
}

.form-control:focus {
    border-color: #4e73df;
    outline: none;
    box-shadow: 0 0 0 0.2rem rgba(78,115,223,0.25);
}

.btn-primary {
    background: #4e73df;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 5px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background: #2e59d9;
}
</style>

<script>
function salvarPerfilAdmin(event) {
    event.preventDefault();
    
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmar_senha').value;
    
    if (senha && senha !== confirmarSenha) {
        alert('As senhas não coincidem!');
        return;
    }
    
    const dados = {
        nome: document.getElementById('nome').value,
        email: document.getElementById('email').value,
        senha: senha
    };
    
    fetch('ajax/salvar_perfil_admin.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dados)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Perfil atualizado com sucesso!');
            // Atualiza o nome no header se necessário
            const nomeHeader = document.querySelector('.user-info span');
            if (nomeHeader) {
                nomeHeader.textContent = dados.nome;
            }
        } else {
            alert(data.message || 'Erro ao atualizar perfil');
        }
    })
    .catch(error => {
        alert('Erro ao salvar: ' + error.message);
    });
}

function salvarConfiguracoes(event) {
    event.preventDefault();
    
    const dados = {
        taxa_saque: parseFloat(document.getElementById('taxa_saque').value),
        valor_minimo_saque: parseFloat(document.getElementById('valor_minimo_saque').value)
    };
    
    fetch('ajax/salvar_configuracoes.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dados)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Configurações salvas com sucesso!');
        } else {
            alert(data.message || 'Erro ao salvar configurações');
        }
    })
    .catch(error => {
        alert('Erro ao salvar: ' + error.message);
    });
}
</script>

<?php
$content = ob_get_clean();
require_once 'includes/layout.php';
?> 