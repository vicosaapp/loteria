<?php
require_once '../config/database.php';
session_start();

// Retornar como JSON
header('Content-Type: application/json');

// Verificar se usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não está logado']);
    exit;
}

// Pegar dados da requisição
$jsonData = file_get_contents('php://input');
$data = json_decode($jsonData, true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit;
}

try {
    // Validar dados recebidos
    if (!isset($data['jogo_id']) || !isset($data['numeros']) || !is_array($data['numeros'])) {
        throw new Exception('Dados incompletos');
    }

    // Buscar configurações do jogo na tabela jogos (não mais em tipos_jogos)
    $stmt = $pdo->prepare("SELECT * FROM jogos WHERE id = ? AND status = 1");
    $stmt->execute([$data['jogo_id']]);
    $jogo = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$jogo) {
        throw new Exception('Jogo não encontrado ou inativo');
    }

    // Validar quantidade de números
    if (count($data['numeros']) != $jogo['dezenas_premiar']) {
        throw new Exception('Quantidade de números inválida');
    }

    // Validar range dos números
    foreach ($data['numeros'] as $numero) {
        if ($numero < 1 || $numero > $jogo['total_numeros']) {
            throw new Exception('Número fora do intervalo permitido');
        }
    }

    // Ordenar números
    sort($data['numeros']);
    
    // Preparar string de números
    $numerosString = implode(',', $data['numeros']);

    // Iniciar transação
    $pdo->beginTransaction();

    // Inserir aposta
    $stmt = $pdo->prepare("
        INSERT INTO apostas 
        (usuario_id, tipo_jogo_id, numeros, valor_aposta, status, created_at) 
        VALUES 
        (?, ?, ?, ?, 'pendente', NOW())
    ");

    $stmt->execute([
        $_SESSION['usuario_id'],
        $data['jogo_id'],
        $numerosString,
        $jogo['valor']
    ]);

    // Commit da transação
    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Aposta realizada com sucesso!',
        'aposta_id' => $pdo->lastInsertId()
    ]);

} catch (Exception $e) {
    // Rollback em caso de erro
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao salvar aposta: ' . $e->getMessage()
    ]);
} 