<?php
require_once '../config/database.php';
session_start();

// Verificar se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Verificar se ID foi fornecido
if (!isset($_GET['id'])) {
    die('ID da aposta não fornecido');
}

try {
    // Buscar dados da aposta
    $stmt = $pdo->prepare("
        SELECT 
            a.*,
            u.nome as nome_usuario,
            u.email as email_usuario,
            u.whatsapp as whatsapp,
            j.nome as nome_jogo,
            j.premio as valor_premio
        FROM apostas a
        LEFT JOIN usuarios u ON a.usuario_id = u.id
        LEFT JOIN jogos j ON a.tipo_jogo_id = j.id
        WHERE a.id = ? AND a.status = 'aprovada'
    ");
    
    $stmt->execute([$_GET['id']]);
    $aposta = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$aposta) {
        die('Aposta não encontrada ou não aprovada');
    }

} catch(PDOException $e) {
    die("Erro ao buscar dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comprovante de Aposta #<?php echo str_pad($aposta['id'], 6, '0', STR_PAD_LEFT); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            padding: 20px;
        }
        .comprovante {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px dashed #dee2e6;
        }
        .numero-bola {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background-color: #007bff;
            color: white;
            border-radius: 50%;
            margin: 0 5px;
            font-size: 1.2rem;
            font-weight: bold;
        }
        .info-row {
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .info-label {
            font-weight: bold;
            color: #6c757d;
        }
        .numeros-container {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .status-aprovado {
            color: #00ff66;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .qr-code {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px dashed #dee2e6;
        }
        @media print {
            body {
                background: white;
                padding: 0;
            }
            .comprovante {
                box-shadow: none;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="comprovante">
        <div class="header">
            <h2>Comprovante de Aposta</h2>
            <h4>#<?php echo str_pad($aposta['id'], 6, '0', STR_PAD_LEFT); ?></h4>
        </div>

        <div class="info-row">
            <span class="info-label">Data da Aposta:</span>
            <span><?php echo date('d/m/Y H:i', strtotime($aposta['created_at'])); ?></span>
        </div>

        <div class="info-row">
            <span class="info-label">Apostador:</span>
            <span><?php echo htmlspecialchars($aposta['nome_usuario'] ?? ''); ?></span>
        </div>

        <div class="info-row">
            <span class="info-label">Jogo:</span>
            <span><?php echo htmlspecialchars($aposta['nome_jogo'] ?? ''); ?></span>
        </div>

        <div class="info-row">
            <span class="info-label">Valor da Aposta:</span>
            <span>R$ <?php echo number_format($aposta['valor_aposta'], 2, ',', '.'); ?></span>
        </div>

        <div class="numeros-container">
            <h5 class="mb-3">Números Apostados</h5>
            <?php 
            $numeros = explode(',', $aposta['numeros']);
            foreach ($numeros as $numero): ?>
                <span class="numero-bola"><?php echo $numero; ?></span>
            <?php endforeach; ?>
        </div>

        <div class="info-row">
            <span class="info-label">Status:</span>
            <span class="status-aprovado">✓ Aprovada</span>
        </div>

        <div class="qr-code">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo urlencode('Aposta #' . $aposta['id'] . ' - ' . $aposta['nome_jogo']); ?>" alt="QR Code">
        </div>

        <div class="mt-4 text-center no-print">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Imprimir Comprovante
            </button>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 