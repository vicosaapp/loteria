<?php
require_once 'includes/header.php';
require_once '../config/database.php';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Define a página atual para o menu
$currentPage = 'jogos';

// Buscar todos os jogos
$stmt = $pdo->query("SELECT * FROM jogos ORDER BY id DESC");
$jogos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
    <div class="page-header">
        <div class="header-content">
            <h1><i class="fas fa-gamepad"></i> Gerenciar Jogos</h1>
            <p>Gerencie os jogos disponíveis no sistema</p>
        </div>
        <button onclick="abrirModal()" class="btn-create">
            <i class="fas fa-plus-circle"></i>
            <span>Novo Jogo</span>
        </button>
    </div>

    <div class="cards-grid">
        <?php foreach($jogos as $jogo): ?>
            <div class="game-card">
                <div class="card-header">
                    <h3><?php echo htmlspecialchars($jogo['nome']); ?></h3>
                    <div class="badge">
                        <?php echo $jogo['status'] ? 'Ativo' : 'Inativo'; ?>
                    </div>
                </div>
                
                <div class="card-body">
                    <div class="info-row">
                        <div class="info-item">
                            <i class="fas fa-th"></i>
                            <span><?php echo $jogo['dezenas']; ?> dezenas</span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-dollar-sign"></i>
                            <span>R$ <?php echo number_format($jogo['valor'], 2, ',', '.'); ?></span>
                        </div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-item">
                            <i class="fas fa-check-circle"></i>
                            <span>Acertospara ganhar o prêmios: <?php echo $jogo['dezenas_premiar']; ?> números</span>
                        </div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-item prize">
                            <i class="fas fa-trophy"></i>
                            <span>Valor do Prêmio: R$ <?php echo number_format($jogo['premio'], 2, ',', '.'); ?></span>
                        </div>
                    </div>
                    
                    <div class="info-row">
                        <div class="info-item">
                            <i class="fas fa-calendar"></i>
                            <span>Criado em: <?php echo date('d/m/Y H:i', strtotime($jogo['created_at'])); ?></span>
                        </div>
                    </div>

                    <!-- Grid de Números -->
                    <div class="numbers-title">Números Disponíveis:</div>
                    <div class="numbers-grid">
                        <?php for($i = 1; $i <= $jogo['total_numeros']; $i++): ?>
                            <div class="number"><?php echo str_pad($i, 2, '0', STR_PAD_LEFT); ?></div>
                        <?php endfor; ?>
                    </div>
                    
                    <!-- Botões -->
                    <div class="card-actions">
                        <button class="btn-edit" onclick='editarJogo(<?php echo json_encode($jogo); ?>)'>
                            <i class="fas fa-edit"></i>
                            <span>Editar</span>
                        </button>
                        <button class="btn-delete" onclick="excluirJogo(<?php echo $jogo['id']; ?>)">
                            <i class="fas fa-trash"></i>
                            <span>Excluir</span>
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
/* Grid de Cards */
.cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(420px, 1fr));
    gap: 25px;
    padding: 20px;
}

/* Card do Jogo */
.game-card {
    background: linear-gradient(rgba(103, 185, 90, 0.37), rgba(103, 185, 90, 0.37)),
                url('../assets/images/lottery-bg.jpg'); /* Manteremos a imagem de fundo, mas com a nova cor */
    background-color: rgb(103 185 90 / 37%); /* Fallback caso a imagem não carregue */
    background-size: cover;
    background-position: center;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(103, 185, 90, 0.2);
    transition: all 0.3s ease;
    overflow: hidden;
    position: relative;
    backdrop-filter: blur(5px);
    border: 1px solid rgba(255,255,255,0.2);
}

.game-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 25px rgba(103, 185, 90, 0.25);
}

/* Cabeçalho do Card */
.card-header {
    background: linear-gradient(135deg, #4e73df, #224abe);
    padding: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-header h3 {
    color: white;
    font-size: 1.2rem;
    font-weight: 600;
    margin: 0;
    text-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.badge {
    background: #28a745;
    color: white;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 0.8rem;
}

/* Corpo do Card */
.card-body {
    padding: 25px;
    background: rgba(255,255,255,0.9); /* Fundo mais opaco para melhor legibilidade */
}

/* Informações do Jogo */
.info-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding: 10px;
    background: rgba(255,255,255,0.95);
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(103, 185, 90, 0.1);
}

.info-item {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.95rem;
    color: #2c3e50;
}

.info-item i {
    color: #4e73df;
    font-size: 1.1rem;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.info-item.prize {
    color: #27ae60;
    font-weight: 600;
    font-size: 1.1rem;
}

/* Números */
.numbers-title {
    margin: 20px 0 15px;
    font-weight: 600;
    color: #2c3e50;
    text-transform: uppercase;
    font-size: 0.9rem;
    letter-spacing: 0.5px;
}

.numbers-grid {
    display: grid;
    grid-template-columns: repeat(10, 1fr);
    gap: 6px;
    padding: 15px;
    background: rgba(255,255,255,0.9);
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}

.number {
    aspect-ratio: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid #4e73df;
    border-radius: 50%;
    font-size: 0.85rem;
    color: #4e73df;
    background: white;
    transition: all 0.2s ease;
    cursor: pointer;
}

.number:hover {
    background: #4e73df;
    color: white;
    transform: scale(1.1);
}

/* Status Badge */
.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.status-badge.active {
    background: #2ecc71;
    color: white;
}

.status-badge.inactive {
    background: #e74c3c;
    color: white;
}

/* Botões de Ação */
.card-actions {
    padding: 20px;
    display: flex;
    gap: 10px;
    border-top: 1px solid rgba(0,0,0,0.1);
    background: rgba(255,255,255,0.9);
}

.btn-edit, .btn-delete {
    flex: 1;
    padding: 10px 20px;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.btn-edit {
    background: #4e73df;
    color: white;
}

.btn-edit:hover {
    background: #224abe;
    transform: translateY(-2px);
}

.btn-delete {
    background: #e74c3c;
    color: white;
}

.btn-delete:hover {
    background: #c0392b;
    transform: translateY(-2px);
}

/* Responsividade */
@media (max-width: 480px) {
    .cards-grid {
        grid-template-columns: 1fr;
    }
    
    .numbers-grid {
        grid-template-columns: repeat(8, 1fr);
    }
}

/* Botão Novo Jogo */
.btn-create {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: #00ff7f; /* Verde fluorescente */
    color: #000; /* Texto preto para melhor contraste */
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 4px rgba(0,255,127,0.3);
}

.btn-create:hover {
    background: #00ff95; /* Verde fluorescente um pouco mais claro no hover */
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,255,127,0.4);
}

.btn-create i {
    font-size: 1.1rem;
}
</style>

<script>
function editarJogo(jogo) {
    console.log('Dados do jogo:', jogo); // Para debug
    
    document.getElementById('modalTitle').textContent = 'Editar Jogo';
    document.getElementById('jogoId').value = jogo.id;
    document.getElementById('nome').value = jogo.nome;
    document.getElementById('total_numeros').value = jogo.total_numeros;
    document.getElementById('dezenas').value = jogo.dezenas;
    document.getElementById('dezenas_premiar').value = jogo.dezenas_premiar;
    
    // Formata os valores monetários
    let valor = parseFloat(jogo.valor).toFixed(2).replace('.', ',');
    valor = valor.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('valor').value = valor;
    
    let premio = parseFloat(jogo.premio).toFixed(2).replace('.', ',');
    premio = premio.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('premio').value = premio;
    
    document.getElementById('status').value = jogo.status;
    document.getElementById('jogoModal').style.display = 'block';
}

function excluirJogo(id) {
    if(confirm('Tem certeza que deseja excluir este jogo?')) {
        // Implementar exclusão
        alert('Excluir jogo ' + id);
    }
}

$(document).ready(function() {
    $('#btnNovoJogo').click(function() {
        // Implementar criação de novo jogo
        alert('Criar novo jogo');
    });
});

function salvarJogo(formData) {
    fetch('ajax/salvar_jogo.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert(data.message);
            window.location.reload();
        } else {
            alert(data.message || 'Erro ao salvar jogo');
        }
    })
    .catch(error => {
        alert('Erro ao salvar: ' + error.message);
    });
}
</script>

<!-- Modal de Criar/Editar Jogo -->
<div id="jogoModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Novo Jogo</h2>
            <button type="button" class="close" onclick="fecharModal()">&times;</button>
        </div>
        
        <div class="modal-body">
            <form id="jogoForm" onsubmit="prepararDadosParaSalvar(event)">
                <input type="hidden" id="jogoId">
                
                <div class="form-group">
                    <label for="nome">Nome do Jogo</label>
                    <input type="text" 
                           id="nome" 
                           class="form-control" 
                           required 
                           placeholder="Ex: Mega Sena">
                </div>

                <div class="form-row three-columns">
                    <div class="form-group">
                        <label>Total de N° do Jogo</label>
                        <div class="input-suffix">
                            <input type="number" 
                                   id="total_numeros" 
                                   class="form-control" 
                                   required 
                                   min="1"
                                   max="100">
                            <span>números</span>
                        </div>
                        <small>Total de n° disponíveis</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Dezenas para Apostar</label>
                        <div class="input-suffix">
                            <input type="number" 
                                   id="dezenas" 
                                   class="form-control" 
                                   required 
                                   min="1"
                                   placeholder="Ex: 6"
                                   onchange="atualizarMaximoAcertos(this.value)">
                            <span>dezenas</span>
                        </div>
                        <small>Quantos números marcar</small>
                    </div>

                    <div class="form-group">
                        <label>Acertos para Prêmio</label>
                        <div class="input-suffix">
                            <input type="number" 
                                   id="dezenas_premiar" 
                                   class="form-control" 
                                   required 
                                   min="1"
                                   placeholder="Ex: 6">
                            <span>acertos</span>
                        </div>
                        <small>Acertos necessários para ganhar</small>
                    </div>
                </div>

                <div class="form-group">
                    <label>Status do Jogo</label>
                    <select id="status" class="form-control">
                        <option value="1">Ativo</option>
                        <option value="0">Inativo</option>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group flex-1">
                        <label>Valor da Aposta</label>
                        <div class="input-prefix">
                            <span>R$</span>
                            <input type="text" 
                                   id="valor" 
                                   class="form-control money" 
                                   required 
                                   placeholder="0,00"
                                   onkeyup="formatarMoeda(this)">
                        </div>
                    </div>
                    
                    <div class="form-group flex-1">
                        <label>Valor do Prêmio</label>
                        <div class="input-prefix">
                            <span>R$</span>
                            <input type="text" 
                                   id="premio" 
                                   class="form-control money" 
                                   required 
                                   placeholder="0,00"
                                   onkeyup="formatarMoeda(this)">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal()">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Salvar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Funções do Modal
function abrirModal() {
    document.getElementById('modalTitle').textContent = 'Novo Jogo';
    document.getElementById('jogoForm').reset();
    document.getElementById('jogoId').value = '';
    document.getElementById('jogoModal').style.display = 'block';
}

function fecharModal() {
    document.getElementById('jogoModal').style.display = 'none';
}

// Funções auxiliares
function formatarMoeda(campo) {
    let valor = campo.value.replace(/\D/g, '');
    valor = (parseInt(valor) / 100).toFixed(2);
    valor = valor.replace('.', ',');
    valor = valor.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    campo.value = valor;
}

function atualizarMaximoAcertos(dezenasApostar) {
    const dezenasPremiar = document.getElementById('dezenas_premiar');
    dezenasPremiar.max = dezenasApostar;
    if (parseInt(dezenasPremiar.value) > parseInt(dezenasApostar)) {
        dezenasPremiar.value = dezenasApostar;
    }
}

function prepararDadosParaSalvar(event) {
    event.preventDefault();
    
    try {
        let valor = document.getElementById('valor').value;
        let premio = document.getElementById('premio').value;
        
        valor = valor.replace(/\./g, '').replace(',', '.');
        premio = premio.replace(/\./g, '').replace(',', '.');
        
        const formData = {
            id: document.getElementById('jogoId').value,
            nome: document.getElementById('nome').value,
            total_numeros: parseInt(document.getElementById('total_numeros').value),
            dezenas: parseInt(document.getElementById('dezenas').value),
            dezenas_premiar: parseInt(document.getElementById('dezenas_premiar').value),
            valor: parseFloat(valor),
            premio: parseFloat(premio),
            status: document.getElementById('status').value
        };
        
        // Validações
        if (!formData.nome) throw new Error('Nome é obrigatório');
        if (!formData.total_numeros || formData.total_numeros <= 0) throw new Error('Total de números inválido');
        if (!formData.dezenas || formData.dezenas <= 0) throw new Error('Dezenas para apostar inválido');
        if (!formData.dezenas_premiar || formData.dezenas_premiar <= 0) throw new Error('Acertos necessários inválido');
        if (formData.dezenas > formData.total_numeros) throw new Error('Dezenas não pode ser maior que total de números');
        if (isNaN(formData.valor) || formData.valor <= 0) throw new Error('Valor inválido');
        if (isNaN(formData.premio) || formData.premio <= 0) throw new Error('Prêmio inválido');
        
        salvarJogo(formData);
    } catch (error) {
        alert(error.message);
    }
}
</script>

<style>
/* Estilos do Modal */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    position: relative;
    background: #fff;
    margin: 30px auto;
    width: 95%;
    max-width: 800px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

/* ... resto dos estilos do modal ... */
</style>

<?php
$content = ob_get_clean();
require_once 'includes/layout.php';
?>