<?php
phpinfo(); 