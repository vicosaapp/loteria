        <footer class="footer">
            <div class="container">
                <p>&copy; <?php echo date('Y'); ?> Sistema de Loteria. Todos os direitos reservados.</p>
            </div>
        </footer>

        <div class="install-prompt">
            <p>Instale nosso app para uma melhor experiência!</p>
            <button id="installButton" class="btn">Instalar</button>
        </div>

        <script src="/js/app.js"></script>
    </body>
</html> 