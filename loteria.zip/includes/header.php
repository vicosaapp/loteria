<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#007bff">
    <title><?php echo $pageTitle ?? 'Sistema de Loteria'; ?></title>
    
    <link rel="manifest" href="/manifest.json">
    <link rel="icon" type="image/png" href="/images/icon-192x192.png">
    <link rel="apple-touch-icon" href="/images/icon-192x192.png">
    
    <link rel="stylesheet" href="/css/style.css">
    <script src="https://unpkg.com/imask"></script>
</head>
<body>
    <header class="header">
        <div class="container">
            <h1><?php echo $pageTitle ?? 'Sistema de Loteria'; ?></h1>
        </div>
    </header>

    <nav class="nav">
        <div class="container">
            <div class="nav-menu">
                <?php if (isset($_SESSION['usuario_id'])): ?>
                    <?php if ($_SESSION['tipo'] === 'admin'): ?>
                        <a href="/admin/gerenciar_apostas.php" class="btn">Gerenciar Apostas</a>
                        <a href="/admin/usuarios.php" class="btn">Gerenciar Usuários</a>
                    <?php else: ?>
                        <a href="/fazer_aposta.php" class="btn">Nova Aposta</a>
                        <a href="/minhas_apostas.php" class="btn">Minhas Apostas</a>
                    <?php endif; ?>
                    <a href="/logout.php" class="btn btn-danger">Sair</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="install-prompt">
        <p>Instale nosso app para uma melhor experiência!</p>
        <button id="installButton" class="btn">Instalar</button>
    </div> 