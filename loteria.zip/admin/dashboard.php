<?php
session_start();
require_once '../config/database.php';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Define a página atual para o menu
$currentPage = 'dashboard';

// Busca estatísticas
try {
    // Total de apostas
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM apostas");
    $totalApostas = $stmt->fetch()['total'];
    
    // Apostas pendentes
    $stmt = $pdo->query("SELECT COUNT(*) as pendentes FROM apostas WHERE status = 'pendente'");
    $apostasPendentes = $stmt->fetch()['pendentes'];
    
    // Apostas aprovadas
    $stmt = $pdo->query("SELECT COUNT(*) as aprovadas FROM apostas WHERE status = 'aprovada'");
    $apostasAprovadas = $stmt->fetch()['aprovadas'];
    
    // Total de usuários
    $stmt = $pdo->query("SELECT COUNT(*) as usuarios FROM usuarios WHERE tipo = 'usuario'");
    $totalUsuarios = $stmt->fetch()['usuarios'];
    
} catch(PDOException $e) {
    die("Erro ao buscar estatísticas: " . $e->getMessage());
}

// Inicia o buffer de saída
ob_start();
?>

<div class="page-header">
    <h1>Dashboard</h1>
</div>

<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-ticket-alt"></i>
        </div>
        <div class="stat-info">
            <h3>Total de Apostas</h3>
            <div class="stat-number"><?php echo $totalApostas; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-info">
            <h3>Apostas Pendentes</h3>
            <div class="stat-number"><?php echo $apostasPendentes; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-info">
            <h3>Apostas Aprovadas</h3>
            <div class="stat-number"><?php echo $apostasAprovadas; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-info">
            <h3>Total de Usuários</h3>
            <div class="stat-number"><?php echo $totalUsuarios; ?></div>
        </div>
    </div>
</div>

<div class="recent-bets">
    <h2>Últimas Apostas Pendentes</h2>
    <?php
    try {
        $stmt = $pdo->query("
            SELECT a.*, u.nome as usuario_nome 
            FROM apostas a 
            JOIN usuarios u ON a.usuario_id = u.id 
            WHERE a.status = 'pendente' 
            ORDER BY a.created_at DESC 
            LIMIT 5
        ");
        $apostasRecentes = $stmt->fetchAll();
        
        if ($apostasRecentes): ?>
            <table>
                <tr>
                    <th>Data</th>
                    <th>Usuário</th>
                    <th>Números</th>
                    <th>Ações</th>
                </tr>
                <?php foreach($apostasRecentes as $aposta): ?>
                <tr>
                    <td><?php echo date('d/m/Y H:i', strtotime($aposta['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($aposta['usuario_nome']); ?></td>
                    <td><?php echo $aposta['numeros']; ?></td>
                    <td>
                        <a href="gerenciar_apostas.php?id=<?php echo $aposta['id']; ?>" class="btn-primary">
                            Gerenciar
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>Não há apostas pendentes.</p>
        <?php endif;
        
    } catch(PDOException $e) {
        echo "Erro ao buscar apostas recentes: " . $e->getMessage();
    }
    ?>
</div>

<style>
.dashboard-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    display: flex;
    align-items: center;
}

.stat-icon {
    background: #f8f9fa;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 20px;
}

.stat-icon i {
    font-size: 24px;
    color: #3498db;
}

.stat-info {
    flex: 1;
}

.stat-number {
    font-size: 24px;
    font-weight: bold;
    color: #2c3e50;
    margin-top: 5px;
}

.recent-bets {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.recent-bets table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.recent-bets th,
.recent-bets td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #eee;
}

.recent-bets th {
    background: #f8f9fa;
    font-weight: 600;
}

.btn-primary {
    background: #3498db;
    color: white;
    padding: 6px 12px;
    border-radius: 4px;
    text-decoration: none;
    display: inline-block;
}

.btn-primary:hover {
    background: #2980b9;
}
</style>

<?php
$content = ob_get_clean();
require_once 'includes/layout.php';
?> 