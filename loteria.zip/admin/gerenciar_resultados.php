<?php
session_start();
require_once '../config/database.php';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Define a página atual para o menu
$currentPage = 'resultados';

// Buscar jogos ativos
try {
    $stmt = $pdo->query("
        SELECT j.*, 
               COALESCE(r.numeros, '') as resultado,
               r.data_sorteio,
               r.id as resultado_id,
               j.total_numeros,
               j.dezenas_premiar
        FROM jogos j 
        LEFT JOIN resultados r ON j.id = r.jogo_id 
        WHERE j.status = 1 
        ORDER BY j.nome ASC
    ");
    $jogos = $stmt->fetchAll();
} catch(PDOException $e) {
    die("Erro ao buscar jogos: " . $e->getMessage());
}

// Adicione esta função no início do arquivo, após a conexão com o banco de dados
function gerarBotaoResultado($jogo) {
    $dados = array(
        'id' => $jogo['id'],
        'nome' => $jogo['nome'],
        'total_numeros' => $jogo['total_numeros'],
        'dezenas_premiar' => $jogo['dezenas_premiar'],
        'resultado_id' => $jogo['resultado_id'],
        'resultado' => $jogo['resultado'],
        'data_sorteio' => $jogo['data_sorteio']
    );
    
    $dadosJson = htmlspecialchars(json_encode($dados), ENT_QUOTES, 'UTF-8');
    
    if (empty($jogo['resultado'])) {
        return "<button onclick='abrirModalResultado({$dadosJson})' class='btn btn-primary'>
                    <i class='fas fa-plus'></i> Adicionar Resultado
                </button>";
    } else {
        return "<button onclick='abrirModalResultado({$dadosJson})' class='btn btn-outline'>
                    <i class='fas fa-edit'></i> Editar Resultado
                </button>";
    }
}

ob_start();
?>

<div class="page-container">
    <div class="page-header">
        <div class="header-content">
            <h1><i class="fas fa-trophy"></i> Resultados dos Jogos</h1>
            <p>Gerencie os resultados dos sorteios</p>
        </div>
    </div>

    <div class="dashboard-stats">
        <div class="stat-card">
            <div class="stat-icon success">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo count(array_filter($jogos, function($j) { return !empty($j['resultado']); })); ?></h3>
                <p>Resultados Cadastrados</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon warning">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo count(array_filter($jogos, function($j) { return empty($j['resultado']); })); ?></h3>
                <p>Aguardando Resultado</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon info">
                <i class="fas fa-gamepad"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo count($jogos); ?></h3>
                <p>Total de Jogos</p>
            </div>
        </div>
    </div>

    <div class="content-section">
        <div class="cards-grid">
            <?php foreach($jogos as $jogo): ?>
                <div class="game-card <?php echo empty($jogo['resultado']) ? 'pending' : 'completed'; ?>">
                    <div class="card-status">
                        <?php if(empty($jogo['resultado'])): ?>
                            <span class="status-badge warning">
                                <i class="fas fa-clock"></i> Aguardando Resultado
                            </span>
                        <?php else: ?>
                            <span class="status-badge success">
                                <i class="fas fa-check-circle"></i> Resultado Cadastrado
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-header">
                        <h3><?php echo htmlspecialchars($jogo['nome']); ?></h3>
                    </div>
                    
                    <div class="card-body">
                        <div class="game-info">
                            <div class="info-item">
                                <i class="fas fa-dice"></i>
                                <span><?php echo $jogo['total_numeros']; ?> números</span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-check"></i>
                                <span><?php echo $jogo['dezenas_premiar']; ?> para ganhar</span>
                            </div>
                        </div>
                        
                        <?php if(!empty($jogo['resultado'])): ?>
                            <div class="result-numbers">
                                <?php foreach(explode(',', $jogo['resultado']) as $numero): ?>
                                    <span class="number"><?php echo str_pad($numero, 2, '0', STR_PAD_LEFT); ?></span>
                                <?php endforeach; ?>
                            </div>
                            <div class="result-date">
                                <i class="far fa-calendar-alt"></i>
                                <?php echo date('d/m/Y', strtotime($jogo['data_sorteio'])); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-footer">
                        <?php echo gerarBotaoResultado($jogo); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Adicionar o modal após o content-container -->

<div id="resultadoModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-trophy"></i> <span id="modalTitle">Adicionar Resultado</span></h2>
            <button type="button" class="close" onclick="fecharModal()">&times;</button>
        </div>
        
        <div class="modal-body">
            <form id="resultadoForm" onsubmit="salvarResultado(event)">
                <input type="hidden" id="jogoId">
                <input type="hidden" id="resultadoId">
                
                <div class="form-group">
                    <label>Nome do Jogo</label>
                    <input type="text" id="jogoNome" class="form-control" readonly>
                </div>

                <div class="form-group">
                    <label>Data do Sorteio</label>
                    <input type="date" id="dataSorteio" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Números Sorteados</label>
                    <div class="numeros-info">
                        <span>Selecione <span id="qtdDezenas">0</span> números</span>
                        <span id="numerosSelecionados">0 de 0 selecionado(s)</span>
                    </div>
                    
                    <div class="numeros-grid">
                        <?php for($i = 1; $i <= 60; $i++): ?>
                            <button type="button" 
                                    class="numero-btn" 
                                    data-numero="<?php echo $i; ?>" 
                                    onclick="toggleNumero(<?php echo $i; ?>, this)">
                                <?php echo str_pad($i, 2, '0', STR_PAD_LEFT); ?>
                            </button>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" onclick="fecharModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar Resultado</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
/* Ajuste o container principal */
.page-container {
    padding: 20px 20px 20px 40px; /* Aumenta padding à esquerda */
    margin-left: 240px; /* Ajusta margem para o menu lateral */
    width: calc(100% - 240px); /* Ajusta largura considerando menu lateral */
    min-height: 100vh;
    background: #f8f9fa;
}

/* Ajuste o grid de cards */
.cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); /* Reduz tamanho mínimo */
    gap: 20px;
    margin-right: 20px;
}

/* Ajuste os cards */
.game-card {
    width: 100%;
    min-width: 280px;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

/* Ajuste o dashboard stats */
.dashboard-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); /* Reduz tamanho mínimo */
    gap: 20px;
    margin-bottom: 30px;
    margin-right: 20px;
}

/* Ajuste responsivo */
@media (max-width: 1200px) {
    .cards-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    }
}

@media (max-width: 768px) {
    .page-container {
        margin-left: 0;
        width: 100%;
        padding: 15px;
    }
    
    .cards-grid {
        grid-template-columns: 1fr;
        margin-right: 0;
    }
    
    .dashboard-stats {
        grid-template-columns: 1fr;
        margin-right: 0;
    }
}

/* Ajuste o header */
.page-header {
    margin-right: 20px;
    margin-bottom: 30px;
}

/* Ajuste o conteúdo */
.content-section {
    margin-right: -10px; /* Compensa o padding dos cards */
    padding-right: 10px;
    overflow-x: hidden;
}

/* Otimize o espaço dos cards */
.card-header {
    padding: 15px;
}

.card-body {
    padding: 15px;
}

.card-footer {
    padding: 15px;
}

/* Melhore a visualização em telas grandes */
@media (min-width: 1600px) {
    .cards-grid {
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    }
}

/* Ajuste para telas muito grandes */
@media (min-width: 2000px) {
    .page-container {
        max-width: 2000px;
        margin-left: auto;
        margin-right: auto;
    }
}

.page-header {
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 30px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.dashboard-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.stat-icon.success { background: #e8f7f3; color: #2ecc71; }
.stat-icon.warning { background: #fef7e9; color: #f1c40f; }
.stat-icon.info { background: #e9f2fe; color: #3498db; }

.stat-info h3 {
    margin: 0;
    font-size: 24px;
    color: #2c3e50;
}

.stat-info p {
    margin: 5px 0 0;
    color: #7f8c8d;
}

.cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.game-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    position: relative;
}

.game-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 15px rgba(0,0,0,0.1);
}

.card-status {
    padding: 10px;
    text-align: center;
    background: #f8f9fa;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 13px;
}

.status-badge.warning {
    background: #fef7e9;
    color: #f1c40f;
}

.status-badge.success {
    background: #e8f7f3;
    color: #2ecc71;
}

.card-header {
    padding: 20px;
    border-bottom: 1px solid #eee;
}

.card-header h3 {
    margin: 0;
    color: #2c3e50;
    font-size: 18px;
}

.game-info {
    display: flex;
    justify-content: space-around;
    padding: 15px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #7f8c8d;
}

.result-numbers {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: center;
    padding: 15px;
}

.number {
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3498db;
    color: white;
    border-radius: 50%;
    font-weight: 500;
}

.result-date {
    text-align: center;
    color: #7f8c8d;
    padding: 10px;
    font-size: 14px;
}

.card-footer {
    padding: 15px;
    border-top: 1px solid #eee;
    text-align: center;
}

.btn {
    padding: 8px 16px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-primary {
    background: #3498db;
    color: white;
}

.btn-primary:hover {
    background: #2980b9;
    transform: translateY(-2px);
}

.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    position: relative;
    background: white;
    margin: 30px auto;
    padding: 0;
    width: 90%;
    max-width: 600px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.modal-header {
    padding: 15px 20px;
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.modal-header h2 {
    margin: 0;
    font-size: 18px;
    color: #2c3e50;
}

.close {
    border: none;
    background: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}

.modal-body {
    padding: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: #2c3e50;
    font-weight: 500;
}

.form-control {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

.numeros-info {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 4px;
    margin-bottom: 15px;
    font-size: 14px;
    color: #666;
}

.numeros-grid {
    display: grid;
    grid-template-columns: repeat(10, 1fr);
    gap: 8px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
    margin-bottom: 20px;
}

.numero-btn {
    width: 40px;
    height: 40px;
    border: 1px solid #ddd;
    border-radius: 50%;
    background: white;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    color: #2c3e50;
    transition: all 0.2s;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.numero-btn:hover {
    border-color: #3498db;
    color: #3498db;
    transform: scale(1.1);
}

.numero-btn.selecionado {
    background: #3498db;
    border-color: #3498db;
    color: white;
    transform: scale(1.1);
}

.modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .modal-content {
        margin: 10px;
        width: calc(100% - 20px);
    }
    
    .numeros-grid {
        grid-template-columns: repeat(6, 1fr);
    }
}
</style>

<script>
let numerosSelecionados = [];
let totalDezenas = 0;

function abrirModalResultado(jogo) {
    numerosSelecionados = [];
    totalDezenas = parseInt(jogo.dezenas_premiar);
    
    document.getElementById('modalTitle').textContent = 
        jogo.resultado ? 'Atualizar Resultado' : 'Adicionar Resultado';
    document.getElementById('jogoId').value = jogo.id;
    document.getElementById('resultadoId').value = jogo.resultado_id || '';
    document.getElementById('jogoNome').value = jogo.nome;
    document.getElementById('dataSorteio').value = jogo.data_sorteio || '';
    document.getElementById('qtdDezenas').textContent = totalDezenas;
    
    // Limpa seleções anteriores
    document.querySelectorAll('.numero-btn').forEach(btn => {
        btn.classList.remove('selecionado');
    });
    
    // Se já existe resultado, marca os números
    if (jogo.resultado) {
        numerosSelecionados = jogo.resultado.split(',').map(n => parseInt(n.trim()));
        numerosSelecionados.forEach(num => {
            const btn = document.querySelector(`.numero-btn[data-numero="${num}"]`);
            if (btn) btn.classList.add('selecionado');
        });
    }
    
    atualizarContadorSelecao();
    document.getElementById('resultadoModal').style.display = 'block';
}

function toggleNumero(numero, elemento) {
    if (!elemento.classList.contains('selecionado') && numerosSelecionados.length >= totalDezenas) {
        return;
    }
    
    elemento.classList.toggle('selecionado');
    
    const index = numerosSelecionados.indexOf(numero);
    if (index === -1) {
        numerosSelecionados.push(numero);
    } else {
        numerosSelecionados.splice(index, 1);
    }
    
    atualizarContadorSelecao();
}

function atualizarContadorSelecao() {
    document.getElementById('numerosSelecionados').textContent = 
        `${numerosSelecionados.length} de ${totalDezenas} selecionado(s)`;
}

function salvarResultado(event) {
    event.preventDefault();
    
    if (numerosSelecionados.length !== totalDezenas) {
        alert(`Por favor, selecione exatamente ${totalDezenas} números!`);
        return;
    }
    
    const formData = {
        jogo_id: document.getElementById('jogoId').value,
        resultado_id: document.getElementById('resultadoId').value,
        data_sorteio: document.getElementById('dataSorteio').value,
        numeros: numerosSelecionados.sort((a, b) => a - b).join(',')
    };
    
    fetch('ajax/salvar_resultado.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            window.location.reload();
        } else {
            alert(data.message || 'Erro ao salvar resultado');
        }
    });
}

function fecharModal() {
    document.getElementById('resultadoModal').style.display = 'none';
    numerosSelecionados = [];
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    if (event.target == document.getElementById('resultadoModal')) {
        fecharModal();
    }
}

// Adicionar funcionalidade de pesquisa
document.getElementById('pesquisaJogo').addEventListener('input', function(e) {
    const termo = e.target.value.toLowerCase();
    const cards = document.querySelectorAll('.resultado-card');
    
    cards.forEach(card => {
        const nomeJogo = card.dataset.jogo.toLowerCase();
        if(nomeJogo.includes(termo)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
});

// Adicionar funcionalidade de filtro
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        // Remove active de todos os botões
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        // Adiciona active no botão clicado
        this.classList.add('active');
        
        const filtro = this.dataset.filter;
        const cards = document.querySelectorAll('.resultado-card');
        
        cards.forEach(card => {
            if (filtro === 'todos') {
                card.style.display = 'block';
            } else if (filtro === 'com-resultado') {
                card.style.display = card.querySelector('.card-status.com-resultado') ? 'block' : 'none';
            } else if (filtro === 'sem-resultado') {
                card.style.display = card.querySelector('.card-status.sem-resultado') ? 'block' : 'none';
            }
        });
    });
});

// Ordenar cards por data do resultado (mais recentes primeiro)
function ordenarCards() {
    const container = document.querySelector('.cards-grid');
    const cards = Array.from(container.children);
    
    cards.sort((a, b) => {
        const dataA = a.querySelector('.resultado-footer span')?.textContent || '';
        const dataB = b.querySelector('.resultado-footer span')?.textContent || '';
        
        if (!dataA) return 1;  // Sem resultado vai pro final
        if (!dataB) return -1; // Sem resultado vai pro final
        
        return new Date(dataB.split(': ')[1]) - new Date(dataA.split(': ')[1]);
    });
    
    cards.forEach(card => container.appendChild(card));
}

// Chamar ordenação quando a página carregar
document.addEventListener('DOMContentLoaded', ordenarCards);
</script>

<?php
$content = ob_get_clean();
require_once 'includes/layout.php';
?> 