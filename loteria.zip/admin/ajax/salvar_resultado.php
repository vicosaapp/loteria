<?php
session_start();
require_once '../../config/database.php';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    die(json_encode(['success' => false, 'message' => 'Acesso negado']));
}

// Pega os dados do POST
$data = json_decode(file_get_contents('php://input'), true);

try {
    // Validação dos campos obrigatórios
    if (empty($data['jogo_id']) || 
        empty($data['data_sorteio']) || 
        empty($data['numeros'])) {
        throw new Exception('Todos os campos são obrigatórios');
    }

    // Prepara os dados
    $jogo_id = intval($data['jogo_id']);
    $resultado_id = !empty($data['resultado_id']) ? intval($data['resultado_id']) : null;
    $data_sorteio = $data['data_sorteio'];
    $numeros = $data['numeros'];

    // Se tem ID, atualiza. Se não tem, insere
    if ($resultado_id) {
        $stmt = $pdo->prepare("
            UPDATE resultados 
            SET numeros = ?, 
                data_sorteio = ?
            WHERE id = ?
        ");
        $stmt->execute([$numeros, $data_sorteio, $resultado_id]);
        $message = 'Resultado atualizado com sucesso!';
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO resultados (jogo_id, numeros, data_sorteio) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$jogo_id, $numeros, $data_sorteio]);
        $message = 'Resultado cadastrado com sucesso!';
    }

    echo json_encode([
        'success' => true,
        'message' => $message
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 