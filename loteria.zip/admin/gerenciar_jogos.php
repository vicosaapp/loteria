<?php
session_start();
require_once '../config/database.php';

// Verifica se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Define a página atual para o menu
$currentPage = 'jogos';

// Buscar todos os jogos
try {
    $stmt = $pdo->query("SELECT * FROM jogos ORDER BY created_at DESC");
    $jogos = $stmt->fetchAll();
} catch(PDOException $e) {
    die("Erro ao buscar jogos: " . $e->getMessage());
}

// Inicia o buffer de saída
ob_start();
?>

<div class="page-header">
    <div class="header-content">
        <h1><i class="fas fa-gamepad"></i> Gerenciar Jogos</h1>
        <p>Gerencie os jogos disponíveis no sistema</p>
    </div>
    <button onclick="abrirModal()" class="btn-create">
        <i class="fas fa-plus-circle"></i>
        <span>Novo Jogo</span>
    </button>
</div>

<div class="jogos-container">
    <div class="cards-grid">
        <?php if(empty($jogos)): ?>
            <div class="no-data-message">
                <i class="fas fa-dice"></i>
                <h3>Nenhum Jogo Cadastrado</h3>
                <p>Comece criando seu primeiro jogo!</p>
                <button onclick="abrirModal()" class="btn-create-empty">
                    <i class="fas fa-plus-circle"></i> Criar Jogo
                </button>
            </div>
        <?php else: ?>
            <?php foreach($jogos as $jogo): ?>
                <div class="game-card <?php echo $jogo['status'] ? 'active' : 'inactive'; ?>">
                    <div class="card-header">
                        <h3><?php echo htmlspecialchars($jogo['nome']); ?></h3>
                        <div class="status-badge <?php echo $jogo['status'] ? 'active' : 'inactive'; ?>">
                            <?php echo $jogo['status'] ? 'Ativo' : 'Inativo'; ?>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <div class="info-row">
                            <div class="info-item">
                                <i class="fas fa-th"></i>
                                <span><?php echo $jogo['dezenas']; ?> dezenas</span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-dollar-sign"></i>
                                <span>R$ <?php echo number_format($jogo['valor'], 2, ',', '.'); ?></span>
                            </div>
                        </div>
                        <div class="info-row">
                            <div class="info-item prize">
                                <i class="fas fa-trophy"></i>
                                <span>Prêmio: R$ <?php echo number_format($jogo['premio'], 2, ',', '.'); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="card-actions">
                        <button onclick="editarJogo(<?php echo htmlspecialchars(json_encode($jogo)); ?>)" 
                                class="btn-edit" title="Editar">
                            <i class="fas fa-edit"></i>
                            <span>Editar</span>
                        </button>
                        <button onclick="excluirJogo(<?php echo $jogo['id']; ?>)" 
                                class="btn-delete" title="Excluir">
                            <i class="fas fa-trash"></i>
                            <span>Excluir</span>
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal de Criar/Editar Jogo -->
<div id="jogoModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Novo Jogo</h2>
            <button type="button" class="close" onclick="fecharModal()">&times;</button>
        </div>
        
        <div class="modal-body">
            <form id="jogoForm" onsubmit="prepararDadosParaSalvar(event)">
                <input type="hidden" id="jogoId">
                
                <div class="form-group">
                    <label for="nome">Nome do Jogo</label>
                    <input type="text" 
                           id="nome" 
                           class="form-control" 
                           required 
                           placeholder="Ex: Mega Sena">
                </div>

                <div class="form-row three-columns">
                    <div class="form-group">
                        <label>Total de Números do Jogo</label>
                        <div class="input-suffix">
                            <input type="number" 
                                   id="total_numeros" 
                                   class="form-control" 
                                   required 
                                   min="1"
                                   max="100">
                            <span>números</span>
                        </div>
                        <small>Total de números disponíveis</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Dezenas para Apostar</label>
                        <div class="input-suffix">
                            <input type="number" 
                                   id="dezenas" 
                                   class="form-control" 
                                   required 
                                   min="1"
                                   placeholder="Ex: 6 para"
                                   onchange="atualizarMaximoAcertos(this.value)">
                            <span>dezenas</span>
                        </div>
                        <small>Quantos números marcar</small>
                    </div>

                    <div class="form-group">
                        <label>Acertos para Prêmio</label>
                        <div class="input-suffix">
                            <input type="number" 
                                   id="dezenas_premiar" 
                                   class="form-control" 
                                   required 
                                   min="1"
                                   placeholder="Ex: 6 para">
                            <span>acertos</span>
                        </div>
                        <small>Acertos necessários para ganhar</small>
                    </div>
                </div>

                <div class="form-group">
                    <label>Status do Jogo</label>
                    <select id="status" class="form-control">
                        <option value="1">Ativo</option>
                        <option value="0">Inativo</option>
                    </select>
                </div>

                <div class="form-row">
                    <div class="form-group flex-1">
                        <label>Valor da Aposta</label>
                        <div class="input-prefix">
                            <span>R$</span>
                            <input type="text" 
                                   id="valor" 
                                   class="form-control money" 
                                   required 
                                   placeholder="0,00"
                                   onkeyup="formatarMoeda(this)">
                        </div>
                    </div>
                    
                    <div class="form-group flex-1">
                        <label>Valor do Prêmio</label>
                        <div class="input-prefix">
                            <span>R$</span>
                            <input type="text" 
                                   id="premio" 
                                   class="form-control money" 
                                   required 
                                   placeholder="0,00"
                                   onkeyup="formatarMoeda(this)">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal()">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary">
                        Salvar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
/* Estilos Gerais */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.header-content h1 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0;
    color: #2c3e50;
}

.header-content p {
    margin: 5px 0 0;
    color: #666;
}

/* Grid de Cards */
.cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    padding: 20px;
}

/* Card do Jogo */
.game-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transition: transform 0.2s, box-shadow 0.2s;
}

.game-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.game-card.inactive {
    opacity: 0.7;
}

.card-header {
    padding: 15px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card-header h3 {
    margin: 0;
    color: #2c3e50;
}

.card-body {
    padding: 15px;
}

.info-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #666;
}

.info-item.prize {
    color: #28a745;
    font-weight: bold;
    font-size: 1.1em;
}

.card-actions {
    padding: 15px;
    border-top: 1px solid #eee;
    display: flex;
    gap: 10px;
}

/* Botões */
.btn-create {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: #2ecc71;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
}

.btn-create:hover {
    background: #27ae60;
}

.btn-edit, .btn-delete {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 8px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
}

.btn-edit {
    background: #3498db;
    color: white;
}

.btn-edit:hover {
    background: #2980b9;
}

.btn-delete {
    background: #e74c3c;
    color: white;
}

.btn-delete:hover {
    background: #c0392b;
}

/* Status Badge */
.status-badge {
    padding: 4px 8px;
    border-radius: 15px;
    font-size: 12px;
    font-weight: bold;
}

.status-badge.active {
    background: #2ecc71;
    color: white;
}

.status-badge.inactive {
    background: #e74c3c;
    color: white;
}

/* Modal */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
}

.modal-content {
    position: relative;
    background: #fff;
    margin: 30px auto;
    width: 95%;
    max-width: 800px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.modal-header {
    padding: 20px 25px;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    margin: 0;
    font-size: 1.5rem;
    color: #333;
}

.modal-body {
    padding: 25px;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-row {
    display: flex;
    gap: 25px;
    margin-bottom: 1.5rem;
}

.three-columns {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 25px;
}

.form-control {
    width: 100%;
    padding: 10px 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 15px;
}

.input-suffix, .input-prefix {
    display: flex;
    align-items: center;
}

.input-suffix span {
    padding: 10px 15px;
    background: #f8f9fa;
    border: 1px solid #ddd;
    border-left: none;
    border-radius: 0 4px 4px 0;
    color: #666;
    font-size: 15px;
}

.input-suffix input {
    border-right: none;
    border-radius: 4px 0 0 4px;
}

.input-prefix span {
    padding: 10px 15px;
    background: #f8f9fa;
    border: 1px solid #ddd;
    border-right: none;
    border-radius: 4px 0 0 4px;
    color: #666;
    font-size: 15px;
}

.input-prefix input {
    border-left: none;
    border-radius: 0 4px 4px 0;
    text-align: right;
}

.modal-footer {
    padding: 20px 25px;
    border-top: 1px solid #eee;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 15px;
}

.btn-primary {
    background: #007bff;
    color: white;
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #333;
    font-size: 15px;
}

small {
    display: block;
    margin-top: 8px;
    color: #666;
    font-size: 13px;
}

.flex-1 {
    flex: 1;
}

/* Mensagem Sem Dados */
.no-data-message {
    text-align: center;
    padding: 40px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.no-data-message i {
    font-size: 48px;
    color: #95a5a6;
    margin-bottom: 20px;
}

.no-data-message h3 {
    margin: 0 0 10px;
    color: #2c3e50;
}

.no-data-message p {
    color: #666;
    margin-bottom: 20px;
}

.btn-create-empty {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: #2ecc71;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s;
}

.btn-create-empty:hover {
    background: #27ae60;
}

/* Estilo específico para campos de moeda */
.input-group .money {
    text-align: right;
    font-family: monospace;
    font-size: 1.1rem;
    letter-spacing: 1px;
}

.input-group-text {
    font-weight: bold;
    color: #2c3e50;
    background-color: #f8f9fa;
    border-right: none;
}

.input-group .form-control {
    border-left: none;
}

.input-group .form-control:focus {
    border-left: none;
    box-shadow: none;
}

.input-group .form-control:focus + .input-group-text {
    border-color: #80bdff;
}
</style>

<script>
function abrirModal() {
    document.getElementById('modalTitle').textContent = 'Novo Jogo';
    document.getElementById('jogoForm').reset();
    document.getElementById('jogoId').value = '';
    document.getElementById('jogoModal').style.display = 'block';
}

function editarJogo(jogo) {
    document.getElementById('modalTitle').textContent = 'Editar Jogo';
    document.getElementById('jogoId').value = jogo.id;
    document.getElementById('nome').value = jogo.nome;
    document.getElementById('total_numeros').value = jogo.total_numeros;
    document.getElementById('dezenas').value = jogo.dezenas;
    
    // Formata os valores para exibição
    let valor = parseFloat(jogo.valor).toFixed(2).replace('.', ',');
    valor = valor.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('valor').value = valor;
    
    let premio = parseFloat(jogo.premio).toFixed(2).replace('.', ',');
    premio = premio.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    document.getElementById('premio').value = premio;
    
    document.getElementById('status').value = jogo.status;
    document.getElementById('jogoModal').style.display = 'block';
}

function fecharModal() {
    document.getElementById('jogoModal').style.display = 'none';
}

function formatarMoeda(campo) {
    // Remove tudo que não é número
    let valor = campo.value.replace(/\D/g, '');
    
    // Converte para número e divide por 100 para ter os centavos
    valor = (parseInt(valor) / 100).toFixed(2);
    
    // Formata com pontos e vírgulas
    valor = valor.replace('.', ',');
    valor = valor.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
    
    campo.value = valor;
}

function atualizarMaximoAcertos(dezenasApostar) {
    const dezenasPremiar = document.getElementById('dezenas_premiar');
    dezenasPremiar.max = dezenasApostar;
    
    // Se o valor atual for maior que o máximo permitido, ajusta
    if (parseInt(dezenasPremiar.value) > parseInt(dezenasApostar)) {
        dezenasPremiar.value = dezenasApostar;
    }
}

function prepararDadosParaSalvar(event) {
    event.preventDefault();
    
    try {
        let valor = document.getElementById('valor').value;
        let premio = document.getElementById('premio').value;
        
        valor = valor.replace(/\./g, '').replace(',', '.');
        premio = premio.replace(/\./g, '').replace(',', '.');
        
        const totalNumeros = parseInt(document.getElementById('total_numeros').value);
        const dezenas = parseInt(document.getElementById('dezenas').value);
        const dezenasPremiar = parseInt(document.getElementById('dezenas_premiar').value);
        
        // Validações específicas
        if (dezenasPremiar > dezenas) {
            throw new Error('Acertos necessários não pode ser maior que dezenas apostadas');
        }
        
        const formData = {
            id: document.getElementById('jogoId').value,
            nome: document.getElementById('nome').value,
            total_numeros: totalNumeros,
            dezenas: dezenas,
            dezenas_premiar: dezenasPremiar,
            valor: parseFloat(valor),
            premio: parseFloat(premio),
            status: document.getElementById('status').value
        };
        
        // Validações
        if (!formData.nome) throw new Error('Nome é obrigatório');
        if (!formData.total_numeros || formData.total_numeros <= 0) throw new Error('Total de números inválido');
        if (!formData.dezenas || formData.dezenas <= 0) throw new Error('Dezenas para apostar inválido');
        if (!formData.dezenas_premiar || formData.dezenas_premiar <= 0) throw new Error('Acertos necessários inválido');
        if (formData.dezenas > formData.total_numeros) throw new Error('Dezenas não pode ser maior que total de números');
        if (isNaN(formData.valor) || formData.valor <= 0) throw new Error('Valor inválido');
        if (isNaN(formData.premio) || formData.premio <= 0) throw new Error('Prêmio inválido');
        
        salvarJogo(formData);
    } catch (error) {
        alert(error.message);
    }
}

function salvarJogo(formData) {
    fetch('ajax/salvar_jogo.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert(data.message);
            window.location.reload();
        } else {
            alert(data.message || 'Erro ao salvar jogo');
        }
    })
    .catch(error => {
        alert('Erro ao salvar: ' + error.message);
    });
}

function excluirJogo(id) {
    if(confirm('Tem certeza que deseja excluir este jogo?')) {
        fetch('ajax/excluir_jogo.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id })
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                window.location.reload();
            } else {
                alert(data.message || 'Erro ao excluir jogo');
            }
        });
    }
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    if (event.target == document.getElementById('jogoModal')) {
        fecharModal();
    }
}

// Fechar modal ao clicar no X
document.querySelector('.close').onclick = fecharModal;
</script>

<?php
$content = ob_get_clean();
require_once 'includes/layout.php';
?>